from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

# Configuration
url = "https://raydium.io/swap/?inputMint=sol&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
css_selector = "input[name='swap']"
poll_interval = 1  # seconds

options = Options()
options.add_experimental_option("detach", True)


# Setup driver
driver = webdriver.Chrome(options=options)
driver.get(url)

# Wait for the page to load and the element to be present
WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.CSS_SELECTOR, css_selector))
)

# Wait for the agreement checkbox to be clickable
WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.CSS_SELECTOR, "span.chakra-checkbox__control.css-1oq4bav"))
)

agreement_box = driver.find_element(By.CSS_SELECTOR, "span.chakra-checkbox__control.css-1oq4bav")
agreement_box.click()

# Wait for the agreement button to be interactable
WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.CSS_SELECTOR, "button.chakra-button.css-1y4lpbv"))
)

# Check if there is no "disabled" class on the button
agreement_button = driver.find_element(By.CSS_SELECTOR, "button.chakra-button.css-1y4lpbv")
if "disabled" not in agreement_button.get_attribute("class"):
    agreement_button.click()

# Wait for the element to appear
element = driver.find_elements(By.CSS_SELECTOR, css_selector)
input_token = element[0] if element else None

refresh_time = 10

if input_token:
    # Fill the input field with a value
    print(input_token)
    input_token.send_keys("1")
    print("Input field found and value set to 1.")

    current_value = 0

    # Wait for the refresh button to be presented
    WebDriverWait(driver, refresh_time).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "div.css-k008qs > div.css-4g6ai3"))
    )

    refresh_button = driver.find_element(By.CSS_SELECTOR, "div.css-k008qs > div.css-4g6ai3")

    while True:
        output_token = element[1] if len(element) > 1 else None
        if output_token:
            # Get the current value from the output field
            current_value = output_token.get_attribute("value")
            print(f"Current output value: {current_value}")
        else:
            print("Output field not found.")
        
        if refresh_time > 10 and refresh_time % 10 == 0:
            # Click the refresh button every 5 seconds
            refresh_button.click()

        refresh_time += 1
        time.sleep(poll_interval)  # Wait before checking again
else:
    print("Input field not found.")




# driver.quit()  # Close browser when done
