from solana.rpc.api import Client
from construct import Struct, Int64ul
from solders.pubkey import Pubkey

# Raydium SOL/USDC AMM pool account (example mainnet pool)
POOL_ADDRESS = "3ucNos4NbumPLZNWztqGHNFFgkHeRMBQAVemeeomsUxv"  # Raydium SOL/USDC

# Initialize RPC client
client = Client("https://api.mainnet-beta.solana.com")

# Raydium AMM layout (simplified to reserve info)
RaydiumPoolLayout = Struct(
    "padding1" / Int64ul,
    "padding2" / Int64ul,
    "padding3" / Int64ul,
    "padding4" / Int64ul,
    "reserve_token_a" / Int64ul,  # SOL
    "reserve_token_b" / Int64ul,  # USDC
)

def get_pool_state():
    acc_info = client.get_account_info(Pubkey.from_string(POOL_ADDRESS))
    data = acc_info.value.data
    decoded = RaydiumPoolLayout.parse(data)
    return decoded.reserve_token_a, decoded.reserve_token_b

def simulate_swap(amount_in, reserve_in, reserve_out, fee=0.0025):
    amount_in_with_fee = amount_in * (1 - fee)
    numerator = amount_in_with_fee * reserve_out
    denominator = reserve_in + amount_in_with_fee
    return numerator / denominator

# Example usage
reserve_a, reserve_b = get_pool_state()
sol_input = 1 * 1e9  # 1 SOL in lamports

usdc_output = simulate_swap(sol_input, reserve_a, reserve_b)
print(f"1 SOL ≈ {usdc_output / 1e6} USDC (Raydium pool only)")
