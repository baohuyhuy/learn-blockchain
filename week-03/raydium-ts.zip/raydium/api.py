import requests

def get_swap_quote(sol_amount=1.0):
    url = "https://quote-api.jup.ag/v6/quote"
    lamports = int(sol_amount * 1e9)

    params = {
        "inputMint": "So11111111111111111111111111111111111111112",  # SOL
        "outputMint": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC
        "amount": lamports,
        "slippage": 0.5
    }

    response = requests.get(url, params=params)
    data = response.json()

    out_amount = int(data['outAmount']) / 1e6
    print(f"{sol_amount} SOL ≈ {out_amount:.4f} USDC")

get_swap_quote()
