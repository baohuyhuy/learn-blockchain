import asyncio
import websockets
import json
import base64
import struct
from solders.pubkey import Pubkey

POOL_ACCOUNT = "6U4TBh3aJgiJ5EqCDEua4rP75HsqcfHapMKhhyuTqGuo"
WS_ENDPOINT = "wss://api.mainnet-beta.solana.com"

async def decode_pool_data(data: bytes) -> tuple[int, int]:
    """Decode token_a_amount and token_b_amount from Raydium AMM pool data."""
    # Assuming AMM pool layout: token_a_amount at offset 8, token_b_amount at offset 16 (u64 each)
    # Adjust offsets based on actual Raydium AMM schema if needed
    token_a_amount = struct.unpack("<Q", data[8:16])[0]  # u64, little-endian
    token_b_amount = struct.unpack("<Q", data[16:24])[0]  # u64, little-endian
    return token_a_amount, token_b_amount

async def calculate_price(token_a_amount: int, token_b_amount: int, decimals_a: int = 6, decimals_b: int = 9) -> float:
    """Calculate price as token_b / token_a, adjusted for decimals."""
    if token_a_amount == 0:
        return 0.0
    # Adjust for token decimals (e.g., USDC=6, SOL=9)
    adjusted_a = token_a_amount / (10 ** decimals_a)
    adjusted_b = token_b_amount / (10 ** decimals_b)
    return adjusted_b / adjusted_a  # Price of token_a in terms of token_b

async def listen():
    async with websockets.connect(WS_ENDPOINT) as ws:
        sub_msg = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "accountSubscribe",
            "params": [POOL_ACCOUNT, {"encoding": "base64"}]
        }
        await ws.send(json.dumps(sub_msg))

        while True:
            response = await ws.recv()
            msg = json.loads(response)
            try:
                data = msg["params"]["result"]["value"]["data"][0]
                token_a_amount, token_b_amount = await decode_pool_data(base64.b64decode(data))
                
                # Calculate price (e.g., SOL/USDC price)
                price = await calculate_price(token_a_amount, token_b_amount)
                
                # Log the update
                print(f"Token A Amount: {token_a_amount} (~{token_a_amount / 10**6:.2f} USDC)")
                print(f"Token B Amount: {token_b_amount} (~{token_b_amount / 10**9:.6f} SOL)")
                print(f"Price (SOL/USDC): {price:.6f}")
                print("-" * 50)

            except Exception as e:
                print("Error parsing:", e)

asyncio.run(listen())
