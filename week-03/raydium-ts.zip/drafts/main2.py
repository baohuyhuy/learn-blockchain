import asyncio
import base64
import struct
from solana.rpc.websocket_api import connect
from solders.pubkey import Pubkey
import json

# Configuration
RPC_WEBSOCKET = "wss://api.mainnet-beta.solana.com"  # Replace with Helius/QuickNode for production
POOL_ADDRESS = "5o57r3r8JSJhfaZWN5im6Ngirp2AJHk5dfUBuzhMgdPd"  # Example Raydium pool address (e.g., USDC/SOL)

async def decode_pool_data(data: bytes) -> tuple[int, int]:
    """Decode token_a_amount and token_b_amount from Raydium AMM pool data."""
    # Assuming AMM pool layout: token_a_amount at offset 8, token_b_amount at offset 16 (u64 each)
    # Adjust offsets based on actual Raydium AMM schema if needed
    token_a_amount = struct.unpack("<Q", data[8:16])[0]  # u64, little-endian
    token_b_amount = struct.unpack("<Q", data[16:24])[0]  # u64, little-endian
    return token_a_amount, token_b_amount

async def calculate_price(token_a_amount: int, token_b_amount: int, decimals_a: int = 6, decimals_b: int = 9) -> float:
    """Calculate price as token_b / token_a, adjusted for decimals."""
    if token_a_amount == 0:
        return 0.0
    # Adjust for token decimals (e.g., USDC=6, SOL=9)
    adjusted_a = token_a_amount / (10 ** decimals_a)
    adjusted_b = token_b_amount / (10 ** decimals_b)
    return adjusted_b / adjusted_a  # Price of token_a in terms of token_b

async def monitor_pool():
    async with connect(RPC_WEBSOCKET) as ws:
        # Subscribe to the pool account
        subscription_request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "accountSubscribe",
            "params": [
                POOL_ADDRESS,
                {
                    "encoding": "base64",
                    "commitment": "confirmed"
                }
            ]
        }
        
        # Send subscription request
        await ws.send(json.dumps(subscription_request))
        
        while True:
            try:
                msg = await ws.recv()
                data = json.loads(msg)
                
                # Handle subscription confirmation
                if 'result' in data and isinstance(data['result'], int):
                    subscription_id = data['result']
                    print(f"Subscribed to pool {POOL_ADDRESS} with subscription ID {subscription_id}")
                    continue
                
                # Handle account updates
                if 'params' in data and 'result' in data['params']:
                    account_info = data['params']['result']
                    account_data = base64.b64decode(account_info['value']['data'][0])
                    token_a_amount, token_b_amount = await decode_pool_data(account_data)
                    
                    # Calculate price (e.g., SOL/USDC price)
                    price = await calculate_price(token_a_amount, token_b_amount)
                    
                    # Log the update
                    print(f"Pool Update - Slot: {account_info['context']['slot']}")
                    print(f"Token A Amount: {token_a_amount} (~{token_a_amount / 10**6:.2f} USDC)")
                    print(f"Token B Amount: {token_b_amount} (~{token_b_amount / 10**9:.6f} SOL)")
                    print(f"Price (SOL/USDC): {price:.6f}")
                    print("-" * 50)
                    
            except KeyboardInterrupt:
                print("\nStopping pool monitor...")
            except Exception as e:
                print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(monitor_pool())