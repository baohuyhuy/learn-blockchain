import asyncio
import websockets
import json
import base64
from solders.pubkey import Pubkey

POOL_ACCOUNT = "6U4TBh3aJgiJ5EqCDEua4rP75HsqcfHapMKhhyuTqGuo"
WS_ENDPOINT = "wss://api.mainnet-beta.solana.com"

def decode_pool_data(data_base64):
    decoded = base64.b64decode(data_base64)
    
    # For Raydium AmmV3 pool layout
    # Reserve info are usually at fixed offsets (e.g., offset 72–88 for reserve 0)
    reserve0 = int.from_bytes(decoded[72:80], "little")
    reserve1 = int.from_bytes(decoded[88:96], "little")
    
    return reserve0, reserve1

def decode_token_mints(raw: bytes):
    token_a_mint = Pubkey(raw[8:40])
    token_b_mint = Pubkey(raw[40:72])
    return token_a_mint, token_b_mint

def get_output_amount(input_amount, input_reserve, output_reserve):
    input_with_fee = input_amount * 0.997
    return (input_with_fee * output_reserve) / (input_reserve + input_with_fee)

async def listen():
    async with websockets.connect(WS_ENDPOINT) as ws:
        sub_msg = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "accountSubscribe",
            "params": [POOL_ACCOUNT, {"encoding": "base64"}]
        }
        await ws.send(json.dumps(sub_msg))

        while True:
            response = await ws.recv()
            msg = json.loads(response)
            try:
                data = msg["params"]["result"]["value"]["data"][0]
                reserve0, reserve1 = decode_pool_data(data)

                token_a_reserve = reserve0 / 1e9  # Assuming SOL
                token_b_reserve = reserve1 / 1e6  # Assuming USDC

                print(f"[REAL-TIME] SOL Reserve: {token_a_reserve:.4f} SOL")
                print(f"[REAL-TIME] USDC Reserve: {token_b_reserve:.4f} USDC")

                # Constant product AMM: x*y=k → swap 1 SOL → ? USDC
                amount_in = 1  # 1 SOL
                amount_out = get_output_amount(amount_in, token_a_reserve, token_b_reserve)
                print(f"[REAL-TIME] 1 SOL ≈ {amount_out:.4f} USDC")

            except Exception as e:
                print("Error parsing:", e)

asyncio.run(listen())
