import { Connection, PublicKey } from '@solana/web3.js'
import { API_URLS } from '@raydium-io/raydium-sdk-v2'

console.log('API URLs:', API_URLS)

const connection = new Connection('https://api.mainnet-beta.solana.com')

const tokenAVault = new PublicKey('3JAmmzwwtUpTsLVyB1cmKcyHhZwwSDpFj18y1Uotho5x')
const tokenBVault = new PublicKey('EtDURcPSXyMzEDWwoezyoGGwDxMEAYdzJTmRk6sFYrJB')

async function getTokenBalanceAndDecimals(vault: PublicKey): Promise<{ amount: bigint, decimals: number }> {
  const info = await connection.getTokenAccountBalance(vault);
  return { amount: BigInt(info.value.amount), decimals: info.value.decimals };
}

function getAmountOut(
    inputAmount: bigint,
    reserveIn: bigint,
    reserveOut: bigint
): bigint {
    // --- 1. Define Fee Constants (Raydium V4 uses 0.25%) ---
    // LIQUIDITY_FEES_NUMERATOR = 25n
    // LIQUIDITY_FEES_DENOMINATOR = 10000n (0.25% = 25/10000)
    const LIQUIDITY_FEES_NUMERATOR = 25n;
    const LIQUIDITY_FEES_DENOMINATOR = 10000n;

    // --- 2. Calculate the Fee ---
    // feeRaw = (inputAmount * LIQUIDITY_FEES_NUMERATOR) / LIQUIDITY_FEES_DENOMINATOR;
    // BigInt division naturally truncates towards zero (like floor for positive numbers)
    const feeRaw = (inputAmount * LIQUIDITY_FEES_NUMERATOR) / LIQUIDITY_FEES_DENOMINATOR;

    // Note: For a true `ceil` division with BigInt, you might do:
    // const feeRaw = (inputAmount * LIQUIDITY_FEES_NUMERATOR + LIQUIDITY_FEES_DENOMINATOR - 1n) / LIQUIDITY_FEES_DENOMINATOR;
    // However, the `div` method in `bn.js` also typically floors for positive numbers, so the simple division here is generally equivalent.

    // --- 3. Calculate Amount In After Fee ---
    const amountInWithFee = inputAmount - feeRaw;

    // --- 4. Apply the Constant Product Formula ---
    // amountOutRaw = (reserveOut * amountInWithFee) / (reserveIn + amountInWithFee);

    // Denominator: reserveIn + amountInWithFee
    const denominator = reserveIn + amountInWithFee;

    // Numerator: reserveOut * amountInWithFee
    const numerator = reserveOut * amountInWithFee;

    // amountOutRaw = Numerator / Denominator
    const amountOutRaw = numerator / denominator;

    return amountOutRaw;
}

async function main() {
  const [vaultA, vaultB] = [tokenAVault, tokenBVault];
  console.log(`Vault A: ${vaultA.toBase58()}`);
  console.log(`Vault B: ${vaultB.toBase58()}`);

  const { amount: reserveA, decimals: decimalsA } = await getTokenBalanceAndDecimals(vaultA);
  const { amount: reserveB, decimals: decimalsB } = await getTokenBalanceAndDecimals(vaultB);

  console.log(`Reserve A: ${reserveA} (Raw) | Human: ${Number(reserveA) / (10 ** decimalsA)} Token A (Decimals: ${decimalsA})`);
  console.log(`Reserve B: ${reserveB} (Raw) | Human: ${Number(reserveB) / (10 ** decimalsB)} Token B (Decimals: ${decimalsB})`);

  // Assume input of 1 token A. We need to scale it by its decimals.
  const inputAmountHuman = 1; // e.g., 1 SOL
  const inputAmountRaw = BigInt(inputAmountHuman * (10 ** decimalsA));

  console.log(`Input Amount (Human): ${inputAmountHuman} Token A`);
  console.log(`Input Amount (Raw): ${inputAmountRaw}`);

  const outputAmountRaw = getAmountOut(inputAmountRaw, reserveA, reserveB);
  const outputHuman = Number(outputAmountRaw) / (10 ** decimalsB); // Convert output based on tokenB decimals

  console.log(`Output Amount (Raw): ${outputAmountRaw} Token B`);
  console.log(`Output Amount (Human): ${outputHuman} Token B`);
}

main().catch(err => {
  console.error('Error:', err)
})
