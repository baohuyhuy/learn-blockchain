/**
 * Calculates the theoretical output amount for a swap in a Constant Product AMM (like Raydium V4),
 * using BigInt for arbitrary precision arithmetic.
 *
 * @param inputAmount The raw (BigInt) amount of the token being sent into the pool.
 * @param reserveIn The raw (BigInt) balance of the input token currently in the pool.
 * @param reserveOut The raw (BigInt) balance of the output token currently in the pool.
 * @returns The raw (BigInt) amount of the output token you would receive, after fees.
 */
function calculateAmmV4AmountOut_BigInt(inputAmount, reserveIn, reserveOut) {
    // --- 1. Define Fee Constants (Raydium V4 uses 0.25%) ---
    // LIQUIDITY_FEES_NUMERATOR = 25n
    // LIQUIDITY_FEES_DENOMINATOR = 10000n (0.25% = 25/10000)
    var LIQUIDITY_FEES_NUMERATOR = 25n;
    var LIQUIDITY_FEES_DENOMINATOR = 10000n;
    // --- 2. Calculate the Fee ---
    // feeRaw = (inputAmount * LIQUIDITY_FEES_NUMERATOR) / LIQUIDITY_FEES_DENOMINATOR;
    // BigInt division naturally truncates towards zero (like floor for positive numbers)
    var feeRaw = (inputAmount * LIQUIDITY_FEES_NUMERATOR) / LIQUIDITY_FEES_DENOMINATOR;
    // Note: For a true `ceil` division with BigInt, you might do:
    // const feeRaw = (inputAmount * LIQUIDITY_FEES_NUMERATOR + LIQUIDITY_FEES_DENOMINATOR - 1n) / LIQUIDITY_FEES_DENOMINATOR;
    // However, the `div` method in `bn.js` also typically floors for positive numbers, so the simple division here is generally equivalent.
    // --- 3. Calculate Amount In After Fee ---
    var amountInWithFee = inputAmount - feeRaw;
    // --- 4. Apply the Constant Product Formula ---
    // amountOutRaw = (reserveOut * amountInWithFee) / (reserveIn + amountInWithFee);
    // Denominator: reserveIn + amountInWithFee
    var denominator = reserveIn + amountInWithFee;
    // Numerator: reserveOut * amountInWithFee
    var numerator = reserveOut * amountInWithFee;
    // amountOutRaw = Numerator / Denominator
    var amountOutRaw = numerator / denominator;
    return amountOutRaw;
}
// --- Example Usage with BigInt ---
// Let's assume SOL has 9 decimals and USDC has 6 decimals.
// We'll represent all values as BigInts by appending 'n'
var SOL_DECIMALS = 9n;
var USDC_DECIMALS = 6n;
// Pool has 100 SOL and 100 USDC
var reserveSOL_raw_bigint = 100n * (Math.pow(10n, SOL_DECIMALS)); // 100 * 10^9 n
var reserveUSDC_raw_bigint = 100n * (Math.pow(10n, USDC_DECIMALS)); // 100 * 10^6 n
// Input: 1 SOL
var input1SOL_raw_bigint = 1n * (Math.pow(10n, SOL_DECIMALS)); // 1 * 10^9 n
console.log("--- Swap 1 SOL for USDC (using BigInt) ---");
console.log("Initial Pool: ".concat(reserveSOL_raw_bigint, " raw SOL, ").concat(reserveUSDC_raw_bigint, " raw USDC"));
console.log("Input Amount: ".concat(input1SOL_raw_bigint, " raw SOL"));
var outputUSDC_raw_bigint = calculateAmmV4AmountOut_BigInt(input1SOL_raw_bigint, reserveSOL_raw_bigint, // reserveIn is SOL
reserveUSDC_raw_bigint // reserveOut is USDC
);
console.log("Calculated Output (raw): ".concat(outputUSDC_raw_bigint, " raw USDC"));
// Convert back to human-readable for display
var outputUSDC_human_bigint = Number(outputUSDC_raw_bigint) / Number(Math.pow(10n, USDC_DECIMALS));
console.log("Calculated Output (human-readable): ".concat(outputUSDC_human_bigint, " USDC"));
console.log("\n--- Swap 100 USDC for SOL (using BigInt) ---");
// Input: 100 USDC
var input100USDC_raw_bigint = 100n * (Math.pow(10n, USDC_DECIMALS)); // 100 * 10^6 n
var outputSOL_raw_bigint = calculateAmmV4AmountOut_BigInt(input100USDC_raw_bigint, reserveUSDC_raw_bigint, // reserveIn is USDC
reserveSOL_raw_bigint // reserveOut is SOL
);
console.log("Calculated Output (raw): ".concat(outputSOL_raw_bigint, " raw SOL"));
var outputSOL_human_bigint = Number(outputSOL_raw_bigint) / Number(Math.pow(10n, SOL_DECIMALS));
console.log("Calculated Output (human-readable): ".concat(outputSOL_human_bigint, " SOL"));
