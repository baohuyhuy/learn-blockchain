select distinct NT.MA_NT, NT.TEN_NT, SPT.TEN_SP
from NHATHAU NT 
join HOSO_THAU HST on HST.MA_NT = NT.MA_NT 
join GOI_THAU GT on GT.MA_GT = HST.MA_GT 
join SANPHAM_THAU SPT on SPT.MA_SP = GT.MA_SP
where NT.TENLOAI = N'Trung bình' and HST.TRUNG_THAU = 'Yes' and year(GT.NGAYMO) = 2021

select NT.MA_NT, NT.TEN_NT, count(HST.MA_GT) as SO_GOITHAU
from NHATHAU NT
join HOSO_THAU HST on HST.MA_NT = NT.MA_NT
join GOI_THAU GT on GT.MA_GT = HST.MA_GT
join SANPHAM_THAU SPT on SPT.MA_SP = GT.MA_SP
where HST.TRUNG_THAU = 'Yes' and SPT.GIA_DUKIEN < 3
group by NT.MA_NT, NT.TEN_NT
having count(HST.MA_GT) >= all(
    select count(HST.MA_GT)
    from NHATHAU NT
    join HOSO_THAU HST on HST.MA_NT = NT.MA_NT
    join GOI_THAU GT on GT.MA_GT = HST.MA_GT
    join SANPHAM_THAU SPT on SPT.MA_SP = GT.MA_SP
    where HST.TRUNG_THAU = 'Yes' and SPT.GIA_DUKIEN < 3
    group by NT.MA_NT, NT.TEN_NT
)