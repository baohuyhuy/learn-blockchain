import { Connection, PublicKey } from '@solana/web3.js';
import {
  LiquidityStateLayoutV4, // Might be used for CPMM, but CLMM has different structures
  // CLMM specific imports from raydium-sdk-v2
  ApiV3PoolInfoConcentratedItem,
  Raydium,
  LiquidityStateLayoutV5, // For CLMM pool state, often used by the SDK internally
} from '@raydium-io/raydium-sdk-v2';
import BN from 'bn.js';
import Decimal from 'decimal.js';

// --- Configuration ---
// Replace with your Solana RPC endpoint (e.g., QuickNode, Alchemy, Helius)
// For local testing, you might use 'http://localhost:8899'
const RPC_ENDPOINT = 'https://api.mainnet-beta.solana.com';

// Replace with the PublicKey of the Raydium CLMM pool you want to query.
// Example (SOL-USDC pool ID on mainnet, verify if still active):
// You can find pool IDs on Raydium's UI or through blockchain explorers.
const CLMM_POOL_ID = '2QdhepnKRTLjjSqPL1PtKNwqrUkoLee5Gqs8bvZhRdMv'; // Example SOL-USDC CLMM pool

// --- Helper Functions ---

/**
 * Converts a raw BN (BigNumber) amount to a human-readable decimal string
 * based on the token's decimals.
 * @param amountBN The amount as a BN object.
 * @param decimals The number of decimals for the token.
 * @returns The human-readable decimal amount as a string.
 */
function toDecimal(amountBN: BN, decimals: number): string {
  if (!amountBN) return '0';
  return new Decimal(amountBN.toString()).div(new Decimal(10).pow(decimals)).toString();
}

/**
 * Converts a Raydium SDK sqrtPrice to a human-readable price.
 * sqrtPrice is typically U128 represented as BN in SDK, with 64 implicit decimal places.
 * Price = (sqrtPrice / 2^64)^2 * (10^decimalsB / 10^decimalsA)
 * @param sqrtPriceX64 The sqrtPrice from the pool state (BN).
 * @param tokenADecimals Decimals of token A (base token).
 * @param tokenBDecimals Decimals of token B (quote token).
 * @returns The current price as a string.
 */
function getPriceFromSqrtPriceX64(
  sqrtPriceX64: BN,
  tokenADecimals: number,
  tokenBDecimals: number
): string {
  // Raydium SDK often handles these calculations internally for currentPrice.
  // But if you need to calculate from raw sqrtPriceX64:
  const Q64 = new Decimal(2).pow(64);
  const sqrtPrice = new Decimal(sqrtPriceX64.toString()).div(Q64);
  const price = sqrtPrice.pow(2);
  const adjustedPrice = price.mul(new Decimal(10).pow(tokenADecimals)).div(new Decimal(10).pow(tokenBDecimals));
  return adjustedPrice.toString();
}


// --- Main Function to Get Pool Factors ---
async function getClmmPoolFactors() {
  console.log('Connecting to Solana RPC:', RPC_ENDPOINT);
  const connection = new Connection(RPC_ENDPOINT, 'confirmed');

  try {
    // Initialize Raydium SDK.
    // Note: For simple data fetching, a dummy owner/wallet might suffice if the SDK
    // methods don't require signing for read operations.
    const sdk = await Raydium.load({
      connection,
    });

    console.log(`Fetching data for CLMM pool ID: ${CLMM_POOL_ID}`);

    // Fetch pool information by ID.
    const poolInfos = await sdk.api.fetchPoolById({ ids: CLMM_POOL_ID });

    if (!poolInfos || poolInfos.length === 0) {
      console.error(`Pool with ID ${CLMM_POOL_ID} not found or no data returned.`);
      return;
    }

    const poolInfo: ApiV3PoolInfoConcentratedItem = poolInfos[0] as ApiV3PoolInfoConcentratedItem;

    console.log('\n--- Raydium CLMM Pool Factors ---');

    // 1. Current Reserves
    // These are the total amounts of tokens held in the pool's vaults.
    // Note: In CLMM, effective reserves for a trade depend on active liquidity within price ranges.
    // These represent the total assets managed by the pool.
    console.log(`\n1. Current Reserves:`);
    console.log(`   Token A (Mint: ${poolInfo.mintA}) Amount: ${toDecimal(new BN(poolInfo.mintAmountA), poolInfo.mintADecimal)}`);
    console.log(`   Token B (Mint: ${poolInfo.mintB}) Amount: ${toDecimal(new BN(poolInfo.mintAmountB), poolInfo.mintBDecimal)}`);
    // Optional: Fetch the actual program account for `LIQUIDITY_STATE_LAYOUT_V5` if `tokenAmount` is not sufficient,
    // but the API usually provides accurate aggregated amounts.

    // 2. Current Price
    // The poolInfo.currentPrice is usually a string representing the current price of Token B per Token A.
    console.log(`\n2. Current Price:`);
    // The currentPrice provided by the API usually reflects TokenB per TokenA.
    console.log(`   ${poolInfo.price} ${poolInfo.mintB} per ${poolInfo.mintA}`);
    // If you wanted to calculate from raw sqrtPriceX64:
    // const calculatedPrice = getPriceFromSqrtPriceX64(
    //   new BN(poolInfo.sqrtPriceX64),
    //   poolInfo.mintADecimal,
    //   poolInfo.mintBDecimal
    // );
    // console.log(`   (Calculated from sqrtPrice: ${calculatedPrice} ${poolInfo.mintB} per ${poolInfo.mintA})`);


    // 3. Liquidity Range (for active liquidity positions)
    // To get the true "Liquidity Range" of all concentrated positions,
    // you'd typically need to query all active LP positions and find their min/max bounds.
    // The pool itself has a current tick, but not a global min/max price range for all liquidity.
    // We can infer a narrow range around the current tick based on tick spacing.
    const currentTickPriceLower = getPriceFromSqrtPriceX64(
      new BN(sdk.clmm.tick.getSqrtPriceX64FromTick(poolInfo.tickCurrent, poolInfo.tickSpacing)),
      poolInfo.mintADecimal,
      poolInfo.mintBDecimal
    );
    const currentTickPriceUpper = getPriceFromSqrtPriceX64(
      new BN(sdk.clmm.tick.getSqrtPriceX64FromTick(poolInfo.tickCurrent + poolInfo.tickSpacing, poolInfo.tickSpacing)),
      poolInfo.mintADecimal,
      poolInfo.mintBDecimal
    );

    console.log(`\n3. Liquidity Range (Current Active Tick's range):`);
    console.log(`   Approximately: ${currentTickPriceLower} to ${currentTickPriceUpper} ${poolInfo.mintB} per ${poolInfo.mintA}`);
    console.log(`   Note: The full 'Liquidity Range' across all LP positions would require querying individual LP positions or iterating all active tick arrays.`);


    // 4. Liquidity Depth
    // `liquidity` from poolInfo usually represents the total *active* liquidity across all concentrated positions.
    // To get the "distribution" (depth chart), you would need to fetch `TickArray` accounts and parse `TickState`s.
    // This is a more involved process. The `sdk.clmm.getRpcClmmPoolInfo` might fetch tick arrays.
    console.log(`\n4. Liquidity Depth:`);
    console.log(`   Total Active Liquidity (L): ${poolInfo.liquidity}`); // This is a sum of all active LPs' liquidity.
    console.log(`   To get detailed distribution (depth chart), you would need to fetch and parse individual TickArray accounts and their TickState data, which is more complex.`);
    // Example (conceptual, requires fetching and decoding tick arrays):
    // const tickArrays = await sdk.clmm.getRpcClmmPoolInfo({ poolId: CLMM_POOL_ID });
    // console.log('   Example of tick data (conceptual):', tickArrays.tickArray);


    // 5. Tick Index
    console.log(`\n5. Tick Index:`);
    console.log(`   Current Tick: ${poolInfo.tickCurrent}`);
    console.log(`   Tick Spacing: ${poolInfo.tickSpacing}`); // Important for understanding tick intervals

    // 6. Fee Tier
    // The feeRate is usually in basis points (e.g., 0.0004 for 0.04%).
    const feePercentage = new Decimal(poolInfo.feeRate).mul(100).toString();
    console.log(`\n6. Fee Tier:`);
    console.log(`   ${feePercentage}% (Raw fee rate: ${poolInfo.feeRate})`);

  } catch (error) {
    console.error('Error fetching Raydium CLMM pool data:', error);
  }
}

// Run the function
getClmmPoolFactors();